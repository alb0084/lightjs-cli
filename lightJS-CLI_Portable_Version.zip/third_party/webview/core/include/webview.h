/**
 * @file webview.h
 *
 * @deprecated This header file is deprecated. Use `webview/webview.h` instead.
 *
 * This file is provided for backward-compatibility with existing code
 * such as `#include "webview.h"`.
 */

#ifndef WEBVIEW_ROOT_H
#define WEBVIEW_ROOT_H

#include "webview/webview.h"

#endif // WEBVIEW_ROOT_H
